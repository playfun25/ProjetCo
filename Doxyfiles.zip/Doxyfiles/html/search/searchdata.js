var indexSectionsWithContent =
{
  0: "acdghilmprstw~",
  1: "chlpst",
  2: "m",
  3: "acdghilprstw~",
  4: "cr"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Espaces de nommage",
  3: "Fonctions",
  4: "Pages"
};

