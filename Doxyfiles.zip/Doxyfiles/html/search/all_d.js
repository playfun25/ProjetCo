var searchData=
[
  ['_7eloraframe_42',['~LoraFrame',['../class_lora_frame.html#a431c1f19789de7e92f47c4c2a27ab202',1,'LoraFrame']]],
  ['_7esensorstrategy_43',['~SensorStrategy',['../class_sensor_strategy.html#a12c1ff2ac0bc1f8804cf8fa748682492',1,'SensorStrategy']]]
];
