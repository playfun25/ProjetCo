var searchData=
[
  ['sensor_80',['Sensor',['../class_sensor.html#a9d269709f2deb2d988a5f1f65e908678',1,'Sensor']]],
  ['sensormanager_81',['SensorManager',['../class_sensor_manager.html#ac2bea3e22536f101970bd20fc72fa5d1',1,'SensorManager']]],
  ['setco2value_82',['setCO2Value',['../class_sensors_last_value.html#a1a020702978780f99f6563db45fa7485',1,'SensorsLastValue']]],
  ['setcovvalue_83',['setCOVValue',['../class_sensors_last_value.html#a3c4d61f156826b5f2d9adff45b903c8c',1,'SensorsLastValue']]],
  ['seteco2value_84',['seteCO2Value',['../class_sensors_last_value.html#a5efb24ecd4b035e10ff88dd335c931ea',1,'SensorsLastValue']]],
  ['sethumidvalue_85',['setHumidValue',['../class_sensors_last_value.html#a718f166c7f95df28cbe872f7b16d933a',1,'SensorsLastValue']]],
  ['setlumivalue_86',['setLumiValue',['../class_sensors_last_value.html#a1f0448e3a1176741e220618b7aa152df',1,'SensorsLastValue']]],
  ['setpressvalue_87',['setpressValue',['../class_sensors_last_value.html#a44daa37fa9749d7efbe536838a3457b6',1,'SensorsLastValue']]],
  ['settempvalue_88',['setTempValue',['../class_sensors_last_value.html#a832f91e899f9e8684831c0d824487d7e',1,'SensorsLastValue']]],
  ['setuvvalue_89',['setUVValue',['../class_sensors_last_value.html#a8c5c7212697bf37969249ddd1b297c18',1,'SensorsLastValue']]]
];
