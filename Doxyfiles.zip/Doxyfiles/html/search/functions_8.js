var searchData=
[
  ['resetperiod_79',['resetPeriod',['../class_sensor.html#a2f6198004ed2214988183cec41426dd1',1,'Sensor']]]
];
