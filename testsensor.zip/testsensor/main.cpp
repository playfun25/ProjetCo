#include<iostream>
#include <unistd.h>
#include <ostream>
#include "sensormanager.h"
int main(int argc, char *argv[])
{
   std::cout << "hello world\n";
    SensorManager sensor;
    int time = 0;
    int i =0;
    for (i = 0 ; i<20;i++){
        time = sensor.wakeUp(time);
        std::cout << "sleep for " << time << " seconds\n" << std::flush;
        std::cout << "temp : " << SensorsLastValue::GetInstance()->getTempValue() << " humid\n" << SensorsLastValue::GetInstance()->getHumidValue() << " co2\n" << SensorsLastValue::GetInstance()->getCO2Value() << std::flush;
        sleep(time);
        std::cout << "reveille\n"<< std::flush;
    }
    return 0;
}
