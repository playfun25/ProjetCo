#include "sensorslastvalue.h"
SensorsLastValue * SensorsLastValue::GetInstance()
{
    if(instance == nullptr){
        instance = new SensorsLastValue();
    }

    return instance;
}
